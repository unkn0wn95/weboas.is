<!DOCTYPE html>
<html>
<head>
	<title>WebOasis - Forum - Index</title>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width" />
	<meta name="mobile-web-app-capable" content="yes" />
	<meta name="description" content="WebOasis - Forum - Index" />
	<link rel="stylesheet" href="https://weboas.is/forum/themes/webOasis/css/index.css?R118" id="index.css" />
	<link rel="stylesheet" href="https://weboas.is/forum/themes/webOasis/css/icons_svg.css?R118" id="icons_svg.css" />
	<link rel="stylesheet" href="https://weboas.is/forum/themes/webOasis/css/font-awesome.min.css?R118" id="font-awesome.min.css" />
	<link rel="stylesheet" href="https://weboas.is/forum/themes/webOasis/css/_dark/index_dark.css?R118" id="index_dark.css" />
	<link rel="stylesheet" href="https://weboas.is/forum/themes/webOasis/css/prettify.css?R118" id="prettify.css" />
	<link rel="canonical" href="https://weboas.is/forum/index.php" />
	<link rel="shortcut icon" sizes="196x196" href="https://weboas.is/forum/themes/webOasis/images/mobile.png" />
	<link rel="help" href="https://weboas.is/forum/index.php?action=help" />
	<link rel="contents" href="https://weboas.is/forum/index.php" />
	<script src="https://weboas.is/forum/themes/default/scripts/jquery-3.6.0.min.js" id="jquery"></script>
	<script src="https://weboas.is/forum/themes/default/scripts/elk_jquery_plugins.js?R118" id="elk_jquery_plugins.js"></script>
	<script src="https://weboas.is/forum/themes/webOasis/scripts/script.js?R118" id="script.js"></script>
	<script src="https://weboas.is/forum/themes/default/scripts/script_elk.js?R118" id="script_elk.js"></script>
	<script src="https://weboas.is/forum/themes/webOasis/scripts/theme.js?R118" id="theme.js"></script>
	<script>
		var elk_theme_url = 'https://weboas.is/forum/themes/webOasis',
			elk_default_theme_url = 'https://weboas.is/forum/themes/default',
			elk_images_url = 'https://weboas.is/forum/themes/webOasis/images',
			elk_smiley_url = 'https://weboas.is/forum/smileys',
			elk_scripturl = 'https://weboas.is/forum/index.php',
			elk_iso_case_folding = false,
			elk_charset = "UTF-8",
			elk_session_id = '8d991b6acf51df11MjpbzERKPZAcdmQ1',
			elk_session_var = 'd991b6acf51d',
			elk_member_id = 0,
			ajax_notification_text = 'Loading...',
			ajax_notification_cancel_text = 'Cancel',
			help_popup_heading_text = 'A little lost? Let me explain:',
			use_click_menu = false,
			todayMod = 2,
			txt_mark_as_read_confirm = 'Are you sure you want to mark ALL messages as read?',
			elk_forum_action = 'action=forum';
	</script>
	<style>
	
		
		.avatarresize {
			max-width:100px;
			max-height:100px;
		}
		
		.wrapper {width: 95%;}
	</style>
</head>
<body id="elkarte" class="action_home">
	<a id="top" href="#skipnav" tabindex="0">Skip to main content</a>
	<a href="#top" id="gotop" title="Go Up">&#8593;</a>
	<a href="#bot" id="gobottom" title="Go Down">&#8595;</a>
	<header id="top_section">
		<aside class="wrapper">
			<div id="top_section_notice" class="user">
				<form action="https://weboas.is/forum/index.php?action=login2;quicklogin" method="post" accept-charset="UTF-8"  onsubmit="hashLoginPassword(this, '8d991b6acf51df11MjpbzERKPZAcdmQ1');">
					<div id="password_login">
						<input type="text" name="user" size="10" class="input_text" placeholder="Username" />
						<input type="password" name="passwrd" size="10" class="input_password" placeholder="Password" />
						<select name="cookielength">
							<option value="60">1 Hour</option>
							<option value="1440">1 Day</option>
							<option value="10080">1 Week</option>
							<option value="43200">1 Month</option>
							<option value="-1" selected="selected">Forever</option>
						</select>
						<input type="submit" value="Log in" />
						<input type="hidden" name="hash_passwrd" value="" />
						<input type="hidden" name="old_hash_passwrd" value="" />
						<input type="hidden" name="d991b6acf51d" value="8d991b6acf51df11MjpbzERKPZAcdmQ1" />
						<input type="hidden" name="iwaoRfMX" value="v3WSWmwKvZEcOcaZTEGIL9aVzUO1bU8x" />
					</div>
				</form>
			</div>
		</aside>
		<section id="header" class="wrapper centerheader">
			<h1 id="forumtitle">
				<a class="forumlink" href="https://weboas.is/forum/index.php">WebOasis - Forum</a>
				<span id="logobox">
					<a href="https://weboas.is/forum/index.php">
						<img id="logo" src="https://weboas.is/media/forumlogo.png" alt="WebOasis - Forum" title="WebOasis - Forum" />
					</a>
				</span>
			</h1>
		</section>
				<nav id="menu_nav">
					<ul id="main_menu" class="wrapper" role="menubar">
						<li id="button_home" class="listlevel1 subsections" aria-haspopup="true">
							<a class="linklevel1 active" href="https://weboas.is/forum/index.php" ><i class="icon icon-menu icon-lg i-home" title="Community"></i> <span class="button_title" aria-hidden="true">Community</span></a>
							<ul class="menulevel2" role="menu">
								<li id="button_help" class="listlevel2">
									<a class="linklevel2" href="https://weboas.is/forum/index.php?action=help" >Help</a>
								</li>
								<li id="button_recent" class="listlevel2">
									<a class="linklevel2" href="https://weboas.is/forum/index.php?action=recent" >Recent Posts</a>
								</li>
							</ul>
						</li>
						<li id="button_login" class="listlevel1">
							<a class="linklevel1" href="https://weboas.is/forum/index.php?action=login" ><i class="icon icon-menu icon-lg i-sign-in" title="Log in"></i> <span class="button_title" aria-hidden="true">Log in</span></a>
						</li>
						<li id="button_register" class="listlevel1">
							<a class="linklevel1" href="https://weboas.is/forum/index.php?action=register" ><i class="icon icon-menu icon-lg i-register" title="Register"></i> <span class="button_title" aria-hidden="true">Register</span></a>
						</li>
					</ul>
				</nav>
	</header>
	<div id="wrapper" class="wrapper">
		<aside id="upper_section">
		</aside>
			<nav>
				<ul class="navigate_section">
					<li class="linktree">
						<span><a href="https://weboas.is/forum/index.php"><i class="icon i-home"><s>Home</s></i></a>
						</span>
					</li>
				</ul>
			</nav>
		<div id="main_content_section"><a id="skipnav"></a>
		<main>
		
		<header class="category_header">
				<a id="c1"></a>WebOasis
		</header>
		<section class="forum_category" id="category_1">
			<ul class="category_boards" id="category_1_boards">
				<li class="board_row board_row_redirect" id="board_2">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=2.0">
							<span class="board_icon i-board-redirect" title="Redirecting to Go Back To WebOasis Home Page"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=2.0" id="b2">Go Back To WebOasis Home Page</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							32,446 Redirects
						</aside>
					</div>
				</li>
				<li class="board_row" id="board_3">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=3.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=3.0" id="b3">News</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							214 Posts<br /> 10 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5760.msg13614#new" title="Re: January 4th 2022 - Sorry &amp; Goodbye">Re: January 4th 2022 ...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2022-01-19 17:42" data-timestamp="1642610524">Yesterday at 05:42:04 pm</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_1">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=1.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=1.0" id="b1">Discussion</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							207 Posts<br /> 40 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5765.msg13602#new" title="Re: Have you heard the news?">Re: Have you heard th...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2022-01-17 07:07" data-timestamp="1642399642">January 17, 2022, 07:07:22 am</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_22">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=22.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=22.0" id="b22">Suggestions</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							164 Posts<br /> 43 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5732.msg13376#new" title="Re: Rocket.Chat topic section ">Re: Rocket.Chat topic...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-12-25 02:30" data-timestamp="1640395823">December 25, 2021, 02:30:23 am</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_59">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=59.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=59.0" id="b59">Bug Report</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							86 Posts<br /> 19 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=1240.msg13268#new" title="Re: REPORT DEAD LINKS HERE">Re: REPORT DEAD LINKS...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-12-07 05:24" data-timestamp="1638851082">December 07, 2021, 05:24:42 am</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_4">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=4.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=4.0" id="b4">Off Topic</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							245 Posts<br /> 93 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=3454.msg13609#new" title="Re: Gore (NSFW) (MORBID) ">Re: Gore (NSFW) (MORB...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2022-01-18 21:53" data-timestamp="1642539222">January 18, 2022, 09:53:42 pm</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c5"></a>Web Development
		</header>
		<section class="forum_category" id="category_5">
			<ul class="category_boards" id="category_5_boards">
				<li class="board_row" id="board_45">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=45.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=45.0" id="b45">WebDev Discussion &amp; Help</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							86 Posts<br /> 66 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5800.msg13616#new" title="LinkTree Clone">LinkTree Clone</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2022-01-19 19:23" data-timestamp="1642616585">Yesterday at 07:23:05 pm</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c24"></a>Programming
		</header>
		<section class="forum_category" id="category_24">
			<ul class="category_boards" id="category_24_boards">
				<li class="board_row" id="board_74">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=74.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=74.0" id="b74">Programming Discussion</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							20 Posts<br /> 14 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=3273.msg12326#new" title="Re: Typing is Hard">Re: Typing is Hard</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-08-16 23:45" data-timestamp="1629150332">August 16, 2021, 11:45:32 pm</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c12"></a>Search Engine Optimization
		</header>
		<section class="forum_category" id="category_12">
			<ul class="category_boards" id="category_12_boards">
				<li class="board_row" id="board_39">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=39.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=39.0" id="b39">Search Engine Optimization</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							14 Posts<br /> 7 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=270.msg12340#new" title="Re: 500 High Quality Backlinks Are Better Than 5 Million Low Quality Backlinks">Re: 500 High Quality ...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-08-20 04:28" data-timestamp="1629426518">August 20, 2021, 04:28:38 am</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c7"></a>Hosting
		</header>
		<section class="forum_category" id="category_7">
			<ul class="category_boards" id="category_7_boards">
				<li class="board_row" id="board_65">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=65.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=65.0" id="b65">Seedboxes</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							6 Posts<br /> 4 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=4475.msg10324#new" title="The Complete Guide to Building Your Own Personal Streaming Service">The Complete Guide to...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-03-22 05:15" data-timestamp="1616386519">March 22, 2021, 05:15:19 am</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c22"></a>Onion/TOR
		</header>
		<section class="forum_category" id="category_22">
			<ul class="category_boards" id="category_22_boards">
				<li class="board_row" id="board_60">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=60.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=60.0" id="b60">Onion/TOR</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							27 Posts<br /> 20 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5290.msg12391#new" title="Re: Sites (NSFW)">Re: Sites (NSFW)</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-08-26 01:45" data-timestamp="1629935123">August 26, 2021, 01:45:23 am</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c13"></a>Computer Discussion
		</header>
		<section class="forum_category" id="category_13">
			<ul class="category_boards" id="category_13_boards">
				<li class="board_row parent_board" id="board_47">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=47.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=47.0" id="b47">Computer Software</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							229 Posts<br /> 94 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5704.msg13290#new" title="Files - A modern and open-source file manager for Windows Superusers">Files - A modern and ...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-12-10 10:22" data-timestamp="1639128165">December 10, 2021, 10:22:45 am</time></span>
						</p>
					</div>
				</li>
				<li class="childboard_row" id="board_47_children">
					<ul class="childboards">
						<li>
							<h4>Sub-boards:</h4>
						</li>
						<li>
							<a href="https://weboas.is/forum/index.php?board=72.0" title="No New Posts (Topics: 11, Posts: 11)">Linux</a>
						</li>
					</ul>
				</li>
				<li class="board_row" id="board_40">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=40.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=40.0" id="b40">Computer Hardware</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							21 Posts<br /> 13 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5677.msg13194#new" title="165Hz monitor">165Hz monitor</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-11-24 08:03" data-timestamp="1637737428">November 24, 2021, 08:03:48 am</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_41">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=41.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=41.0" id="b41">Computer Peripherals</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							13 Posts<br /> 7 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5344.msg12502#new" title="Keyboard Database">Keyboard Database</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-09-05 01:58" data-timestamp="1630799899">September 05, 2021, 01:58:19 am</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_68">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=68.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=68.0" id="b68">Computer &amp; Network Security</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							59 Posts<br /> 26 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=4301.msg13141#new" title="Re: Malicious IPs, IP ranges and Domains">Re: Malicious IPs, IP...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-11-16 15:55" data-timestamp="1637074529">November 16, 2021, 03:55:29 pm</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_48">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=48.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=48.0" id="b48">Networking Equipment</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							16 Posts<br /> 7 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar"><a href=""><img class="avatar" src="https://weboas.is/forum/themes/webOasis/images/default_avatar.png" alt="" /></a></span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=4805.msg11163#new" title="Fingbox">Fingbox</a> </span><span class="board_lastposter">by ayylmao</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-05-17 20:51" data-timestamp="1621277463">May 17, 2021, 08:51:03 pm</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_64">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=64.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=64.0" id="b64">Raspberry Pi &amp; ARM</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							6 Posts<br /> 5 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=4471.msg10316#new" title="CutiePi Tablet">CutiePi Tablet</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-03-21 23:20" data-timestamp="1616365217">March 21, 2021, 11:20:17 pm</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c17"></a>News
		</header>
		<section class="forum_category" id="category_17">
			<ul class="category_boards" id="category_17_boards">
				<li class="board_row" id="board_49">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=49.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=49.0" id="b49">Tech News</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							338 Posts<br /> 241 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5706.msg13293#new" title="1.6 Million WordPress Sites Hit With 13+ Million Attacks In 36 Hours From 16k IP">1.6 Million WordPress...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-12-10 13:48" data-timestamp="1639140511">December 10, 2021, 01:48:31 pm</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_53">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=53.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=53.0" id="b53">World News</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							49 Posts<br /> 26 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5311.msg12441#new" title="Re: Hurricane Ida winds hit 150 mph ahead of Louisiana strike">Re: Hurricane Ida win...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-08-29 20:32" data-timestamp="1630261932">August 29, 2021, 08:32:12 pm</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_54">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=54.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=54.0" id="b54">Political News</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							94 Posts<br /> 62 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5455.msg12729#new" title="Apparently a legit FDA employee talking about forced vaccinations">Apparently a legit FD...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-09-25 01:52" data-timestamp="1632527573">September 25, 2021, 01:52:53 am</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c15"></a>Investing
		</header>
		<section class="forum_category" id="category_15">
			<ul class="category_boards" id="category_15_boards">
				<li class="board_row" id="board_43">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=43.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=43.0" id="b43">Cryptocurrency</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							74 Posts<br /> 32 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=4896.msg12816#new" title="Re: Binance Volitility Trading Bot">Re: Binance Volitilit...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-10-04 23:06" data-timestamp="1633381591">October 04, 2021, 11:06:31 pm</time></span>
						</p>
					</div>
				</li>
				<li class="board_row" id="board_76">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=76.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=76.0" id="b76">Stocks</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							14 Posts<br /> 9 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5258.msg12297#new" title="Daily Price Report">Daily Price Report</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-08-15 17:16" data-timestamp="1629040616">August 15, 2021, 05:16:56 pm</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c4"></a>Links
		</header>
		<section class="forum_category" id="category_4">
			<ul class="category_boards" id="category_4_boards">
				<li class="board_row" id="board_21">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=21.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=21.0" id="b21">Open Directories</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							80 Posts<br /> 46 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=2837.msg13399#new" title="Re: Anime Collection">Re: Anime Collection</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-12-29 23:02" data-timestamp="1640815376">December 29, 2021, 11:02:56 pm</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c8"></a>Discounts
		</header>
		<section class="forum_category" id="category_8">
			<ul class="category_boards" id="category_8_boards">
				<li class="board_row" id="board_33">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=33.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=33.0" id="b33">Deals &amp; Coupon Codes</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							15 Posts<br /> 13 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar"><a href=""><img class="avatar" src="https://weboas.is/forum/themes/webOasis/images/default_avatar.png" alt="" /></a></span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5623.msg13079#new" title="Coupon Extensions &amp; Sites?">Coupon Extensions &amp; S...</a> </span><span class="board_lastposter">by ayylmao</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-11-08 00:37" data-timestamp="1636328274">November 08, 2021, 12:37:54 am</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c9"></a>Entrepreneurship
		</header>
		<section class="forum_category" id="category_9">
			<ul class="category_boards" id="category_9_boards">
				<li class="board_row" id="board_35">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=35.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=35.0" id="b35">Making Money Online</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							39 Posts<br /> 24 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=5285.msg12403#new" title="Re: Tech Interview Handbook">Re: Tech Interview Ha...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2021-08-26 06:15" data-timestamp="1629951320">August 26, 2021, 06:15:20 am</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
		
		<header class="category_header">
				<a id="c20"></a>Hospital
		</header>
		<section class="forum_category" id="category_20">
			<ul class="category_boards" id="category_20_boards">
				<li class="board_row" id="board_57">
					<div class="board_info">
						<a class="icon_anchor" href="https://weboas.is/forum/index.php?board=57.0">
							<span class="board_icon i-board-off" title="No New Posts"></span>
						</a>
						<h3 class="board_name">
							<a href="https://weboas.is/forum/index.php?board=57.0" id="b57">Medicine, Pharmaceuticals, &amp; Drugs</a>
						</h3>
						<h4 class="board_description"></h4>
					</div>
					<div class="board_latest">
						<aside class="board_stats">
							32 Posts<br /> 13 Topics
						</aside>
						<p class="board_lastpost">
							<span class="board_avatar">Anon</span>
							<span class="lastpost_link"><a href="https://weboas.is/forum/index.php?topic=2834.msg13526#new" title="Re: Marijuana (Delivery) (Dispensaries) (Pipes)">Re: Marijuana (Delive...</a> </span><span class="board_lastposter">by Anon</span><span class="board_lasttime"><strong>Last post: </strong><time title="Last post" datetime="2022-01-09 21:03" data-timestamp="1641758614">January 09, 2022, 09:03:34 pm</time></span>
						</p>
					</div>
				</li>
			</ul>
		</section>
	<aside id="info_center" class="forum_category">
		<h2 class="category_header panel_toggle">
				<i id="upshrink_ic" class="hide chevricon i-chevron-up" title="Hide"></i>
			<a href="#" id="upshrink_link">WebOasis - Forum - Info Center</a>
		</h2>
		<ul id="upshrinkHeaderIC" class="category_boards">
			<li class="board_row hslice" id="recent_posts_content">
				<h3 class="ic_section_header">
					<a href="https://weboas.is/forum/index.php?action=recent"><i class="icon i-post-text"></i>Recent Posts</a>
				</h3>
				<table id="ic_recentposts">
					<tr>
						<th class="recentpost">Message</th>
						<th class="recentposter">Author</th>
						<th class="recentboard">Board</th>
						<th class="recenttime">Date</th>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=5800.msg13616;topicseen#msg13616" rel="nofollow">LinkTree Clone</a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=45.0">WebDev Discussion &amp; Help</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-19 19:23" data-timestamp="1642616585">Yesterday at 07:23:05 pm</time></td>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=5760.msg13614;topicseen#msg13614" rel="nofollow">Re: January 4th 2022 - Sorry &amp; Goodbye</a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=3.0">News</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-19 17:42" data-timestamp="1642610524">Yesterday at 05:42:04 pm</time></td>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=3454.msg13609;topicseen#msg13609" rel="nofollow">Re: Gore (NSFW) (MORBID) </a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=4.0">Off Topic</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-18 21:53" data-timestamp="1642539222">January 18, 2022, 09:53:42 pm</time></td>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=5760.msg13604;topicseen#msg13604" rel="nofollow">Re: January 4th 2022 - Sorry &amp; Goodbye</a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=3.0">News</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-17 22:47" data-timestamp="1642456065">January 17, 2022, 10:47:45 pm</time></td>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=5760.msg13603;topicseen#msg13603" rel="nofollow">Re: January 4th 2022 - Sorry &amp; Goodbye</a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=3.0">News</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-17 11:05" data-timestamp="1642413926">January 17, 2022, 11:05:26 am</time></td>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=5765.msg13602;topicseen#msg13602" rel="nofollow">Re: Have you heard the news?</a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=1.0">Discussion</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-17 07:07" data-timestamp="1642399642">January 17, 2022, 07:07:22 am</time></td>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=5792.msg13599;topicseen#msg13599" rel="nofollow">Re: weboasis chat now on matrix</a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=1.0">Discussion</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-16 01:02" data-timestamp="1642291342">January 16, 2022, 01:02:22 am</time></td>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=5792.msg13598;topicseen#msg13598" rel="nofollow">Re: weboasis chat now on matrix</a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=1.0">Discussion</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-15 22:39" data-timestamp="1642282759">January 15, 2022, 10:39:19 pm</time></td>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=637.msg13592;topicseen#msg13592" rel="nofollow">Re: MP3 Link On Front Page</a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=1.0">Discussion</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-15 16:25" data-timestamp="1642260355">January 15, 2022, 04:25:55 pm</time></td>
					</tr>
					<tr>
						<td class="recentpost"><strong><a href="https://weboas.is/forum/index.php?topic=5793.msg13587;topicseen#msg13587" rel="nofollow">HELP?</a></strong></td>
						<td class="recentposter">Anon</td>
						<td class="recentboard"><a href="https://weboas.is/forum/index.php?board=1.0">Discussion</a></td>
						<td class="recenttime"><time title="Last post" datetime="2022-01-15 02:11" data-timestamp="1642209086">January 15, 2022, 02:11:26 am</time></td>
					</tr>
				</table>
			</li>
			<li class="board_row">
				<h3 class="ic_section_header">
					Forum Stats
				</h3>
				<p class="inline">
					11,364 Posts in 5,076 Topics by 4,927 Members - Latest Member: <strong> Anon</strong> - Most Online Today: 37<br />
					Latest Post: <strong>&quot;<a href="https://weboas.is/forum/index.php?topic=5800.msg13616#new" title="LinkTree Clone">LinkTree Clone</a>&quot;</strong>  ( Yesterday at 07:23:05 pm ) - <a href="https://weboas.is/forum/index.php?action=recent">View all recent posts.</a>
				</p>
			</li>
			<li class="board_row">
				<h3 class="ic_section_header">
					<i class="icon i-users"></i>Online Now:
					5 Users, 18 Guests
				</h3>
				<p class="inline">Active in past 30 minutes: Anon, Anon, Anon, Anon, Anon</p>
				<p class="inline membergroups">[<a href="https://weboas.is/forum/index.php?action=groups;sa=members;group=1" style="color: #CD0000">Administrator</a>,&nbsp;<a href="https://weboas.is/forum/index.php?action=groups;sa=members;group=2" style="color: #0066FF">Global Moderator</a>]</p>
			</li>
		</ul>
	</aside>
		</main>
		<aside id="posting_icons">
			<p title="No New Posts"><i class="icon i-board-off"></i>No New Posts</p>
			<p title="Redirect Board"><i class="icon i-board-redirect"></i>Redirect Board</p>
		</aside>
		</div>
	</div>
	<footer id="footer_section"><a id="bot"></a>
		<div class="wrapper">
			<ul></ul>
		</div>
	</footer>
	<script src="https://weboas.is/forum/themes/default/scripts/sha256.js?R118" id="sha256.js"></script>
	<script src="https://weboas.is/forum/themes/default/scripts/elk_jquery_embed.js?R118" id="elk_jquery_embed.js"></script>
	<script src="https://weboas.is/forum/themes/default/scripts/prettify.min.js?R118" id="prettify.min.js"></script>
	<script>
		var oEmbedtext = ({
				embed_limit : 25,
				preview_image : 'Video Preview Image',
				ctp_video : 'Click to play video, double click to load video',
				hide_video : 'Show/Hide video',
				youtube : 'YouTube video:',
				vimeo : 'Vimeo video:',
				dailymotion : 'Dailymotion video:'
			});
		$(function() {
				prettyPrint();
			});
		var oMainHeaderToggle = new elk_Toggle({
						bToggleEnabled: true,
						bCurrentlyCollapsed: false,
						aSwappableContainers: [
							'upper_section','header'
						],
						aSwapClasses: [
							{
								sId: 'upshrink',
								classExpanded: 'chevricon i-chevron-up icon-lg',
								titleExpanded: 'Shrink or expand the header.',
								classCollapsed: 'chevricon i-chevron-down icon-lg',
								titleCollapsed: 'Shrink or expand the header.'
							}
						],
						oThemeOptions: {
							bUseThemeSettings: false,
							sOptionName: 'minmax_preferences',
							sSessionId: elk_session_id,
							sSessionVar: elk_session_var,
							sAdditionalVars: ';minmax_key=upshrink'
						},
						oCookieOptions: {
							bUseCookie: elk_member_id == 0 ? true : false,
							sCookieName: 'upshrink'
						}
					});
		var oInfoCenterToggle = new elk_Toggle({
			bToggleEnabled: true,
			bCurrentlyCollapsed: false,
			aSwappableContainers: [
				'upshrinkHeaderIC'
			],
			aSwapClasses: [
				{
					sId: 'upshrink_ic',
					classExpanded: 'chevricon i-chevron-up',
					titleExpanded: 'Hide',
					classCollapsed: 'chevricon i-chevron-down',
					titleCollapsed: 'Show'
				}
			],
			aSwapLinks: [
				{
					sId: 'upshrink_link',
					msgExpanded: 'WebOasis - Forum - Info Center',
					msgCollapsed: 'WebOasis - Forum - Info Center'
				}
			],
			oThemeOptions: {
				bUseThemeSettings: false,
				sOptionName: 'minmax_preferences',
				sSessionId: elk_session_id,
				sSessionVar: elk_session_var,
				sAdditionalVars: ';minmax_key=info'
			},
			oCookieOptions: {
				bUseCookie: true,
				sCookieName: 'upshrinkIC'
			}
		});
	</script>
</body>
</html>